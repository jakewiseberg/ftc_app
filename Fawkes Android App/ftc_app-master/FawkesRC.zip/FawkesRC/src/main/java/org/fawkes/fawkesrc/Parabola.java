package org.fawkes.fawkesrc;

/**
 * Created by hello_000 on 1/16/2016.
 */
public class Parabola {

    //a(x-h)^2+k

    public Parabola(int a, int h, int k) {

    }

}
